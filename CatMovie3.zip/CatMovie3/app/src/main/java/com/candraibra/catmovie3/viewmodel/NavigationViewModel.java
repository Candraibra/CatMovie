/*
 * *
 *  * Created by Candra Ibra Sanie on 11/28/19 11:12 AM
 *  * Copyright (c) 2019 . All rights reserved.
 *  * Last modified 11/24/19 5:41 PM
 *
 */

package com.candraibra.catmovie3.viewmodel;

import androidx.lifecycle.ViewModel;

public class NavigationViewModel extends ViewModel {
    public int currentPage = 0;

}
